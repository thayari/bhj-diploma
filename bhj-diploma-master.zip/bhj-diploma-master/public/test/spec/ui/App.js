describe("UI/Класс App", function() {

  it("Определён", function() {
    expect(App).to.be.a('function');
  });
});
