/**
 * Временно не используется
 */
class CategoriesWidget {

}
