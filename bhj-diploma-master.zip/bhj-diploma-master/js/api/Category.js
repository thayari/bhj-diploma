/**
 * Данный класс не используется в проекте
 * */
class Category extends Entity {
}

Category.URL = '/category';
